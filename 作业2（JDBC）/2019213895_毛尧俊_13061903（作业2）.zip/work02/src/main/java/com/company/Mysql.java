package com.company;

import java.sql.*;

public class Mysql {
    public void run(String name, String password) throws SQLException {
        System.out.println("content to sql");
        // JDBC连接的URL, 不同数据库有不同的格式:
        // 踩坑，sql默认是美国时间，需要改为中国时间，不然会报错
        // url后面建议加上(?useSSL=false&characterEncoding=utf8) 否则可能会出现乱码，无法连接数据库
        String JDBC_URL = "jdbc:mysql://localhost:3306/java_big_work?useSSL=false&characterEncoding=utf8";
        String JDBC_USER = "root";
        String JDBC_PASSWORD = "022643";

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            try (PreparedStatement count = conn.prepareStatement("SELECT COUNT(*) totalCount FROM `java_big_work`.`user` WHERE `user_name`=? AND `user_password`=?")) {
                // 使用PreparedStatement占位符 赋值语句一定要写在ResultSet之前，不然会报错
                count.setString(1, name); // 注意：索引从1开始
                count.setString(2, password);
                try (ResultSet rs = count.executeQuery()) {
                    int rowCount = 0;
                    if(rs.next()) {
                        rowCount=rs.getInt("totalCount");
                        System.out.println(rowCount);
                    }
                    if (rowCount == 0) {
                        System.out.println("登陆失败！");
                    } else {
                        System.out.println("登陆成功！");
                    }
                }
            }
        }
    }
}
