package com.company;

import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("hello");
        Scanner Sc = new Scanner(System.in);
        Mysql mysql = new Mysql();
        try {
            String name = Sc.next();
            String password = Sc.next();
            mysql.run(name, password);
        } catch (SQLException ex) {
            // handle any errors
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
    }
}
