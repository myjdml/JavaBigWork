package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner Sc = new Scanner(System.in);
        // 定义验证身份证号的正则
        String regex = "(^[1-9]\\d{5}(18|19|20)\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$)|" +
                "(^[1-9]\\d{5}\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}$)";
        String id;
        System.out.println("请输入身份证号：");
        // 验证身份证号是否合法，不合法需重新输入
        while (true) {
            id = Sc.next();
            if (id.matches(regex)) {
                break;
            }
            System.out.println("该身份证号不存在，请重新输入！");
        }
        Person p = new Person(id);
        System.out.println("性别：" + p.getSex());
        System.out.println("年龄：" + p.getAge());
    }
}
