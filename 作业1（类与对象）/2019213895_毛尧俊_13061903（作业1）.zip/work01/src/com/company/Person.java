package com.company;

import java.util.Date;

public class Person {
    private String idNum;
    private Age myAge;
    public Person (String id) {
        this.idNum = id;
        myAge = new Age();
    }

    public String getSex () {
        int sexNum = Integer.parseInt(this.idNum.substring(16, 17));
        if (sexNum%2 == 0) {
            return "女";
        } else {
            return "男";
        }
    }
    public int getAge () {
        myAge.setYear(Integer.parseInt(this.idNum.substring(6, 10)));
        myAge.setMonth(Integer.parseInt(this.idNum.substring(10, 12)));
        myAge.setDay(Integer.parseInt(this.idNum.substring(12, 14)));
        return (new Date().getYear() + 1900) - myAge.getYear();
    }
}
