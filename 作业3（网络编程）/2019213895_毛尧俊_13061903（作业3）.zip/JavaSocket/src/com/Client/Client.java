package com.Client;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        String serverName = "localhost";
        int port = Integer.parseInt("8081");
        Scanner Sc = new Scanner(System.in);

        System.out.println("请输入用户名：");
        String name = Sc.nextLine();

        try
        {
            System.out.println("连接到主机：" + serverName + " ，端口号：" + port);
            Socket client = new Socket(serverName, port);
            System.out.println("远程主机地址：" + client.getRemoteSocketAddress());
            OutputStream outToServer = client.getOutputStream();
            DataOutputStream out = new DataOutputStream(outToServer);
            out.writeUTF(name + "接入服务");
            InputStream inFromServer = client.getInputStream();
            DataInputStream in = new DataInputStream(inFromServer);
            System.out.println("cur");
            System.out.println(in.readUTF());
            for (;;) {
                String message = Sc.nextLine();
                out.writeUTF(name + ": " + message);
                if (message.equals("fuck")) {
                    System.out.println("break");
                    break;
                }
                System.out.println(in.readUTF());
            }
//                client.close();
        }catch(IOException e)
        {
            e.printStackTrace();
        }
    }
}
