package com.Server;

import java.io.IOException;

public class Server {
    public static void main(String[] args) {
        int port = Integer.parseInt("8081");
        try
        {
            Thread t = new GreetingServer(port);
            t.run();
        }catch(IOException e)
        {
            e.printStackTrace();
        }
    }
}
