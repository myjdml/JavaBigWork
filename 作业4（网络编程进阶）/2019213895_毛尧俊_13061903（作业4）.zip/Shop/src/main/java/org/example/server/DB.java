package org.example.server;

import org.example.module.ProductModule;

import java.sql.*;
import java.util.ArrayList;

public class DB {
    private final String dbClassName = "com.mysql.jdbc.Driver";
    private final String url = "jdbc:mysql://localhost:3306/java_big_work?useSSL=false&characterEncoding=utf8&serverTimezone=GMT%2B8";
    private final String user = "root";
    private final String password = "022643";

    public Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName(dbClassName);
        return DriverManager.getConnection(url, user, password);
    }

    public boolean checkUser(String userName, String userPassword) throws SQLException, ClassNotFoundException {
        try (Connection conn = getConnection()) {
            try (PreparedStatement count = conn.prepareStatement(
                    "SELECT COUNT(*) totalCount FROM `java_big_work`.`user` WHERE `user_name`=? AND `user_password`=?"
            )) {
                count.setString(1, userName);
                count.setString(2, userPassword);
                try (ResultSet rs = count.executeQuery()) {
                    int rowCount = 0;
                    if(rs.next()) {
                        rowCount=rs.getInt("totalCount");
                        System.out.println(rowCount);
                    }
                    if (rowCount == 0) {
                        System.out.println("登陆失败！");
                        return false;
                    } else {
                        System.out.println("登陆成功！");
                        return true;
                    }
                }
            }
        }
    }

    public ArrayList<ProductModule> getAllProducts() throws SQLException, ClassNotFoundException {
        try (Connection conn = getConnection()) {
            try (PreparedStatement count = conn.prepareStatement(
                    "SELECT * FROM `java_big_work`.`productions`"
            )) {
                ArrayList<ProductModule> list = new ArrayList<ProductModule>();
                try (ResultSet rs = count.executeQuery()) {
                    while (rs.next()) {
                        ProductModule g = new ProductModule();
                        g.setId(rs.getInt("id"));
                        System.out.println(rs.getInt("id"));
                        g.setSort(rs.getString("sort"));
                        g.setCode(rs.getString("code"));
                        g.setName(rs.getString("name"));
                        g.setPlace(rs.getString("place"));
                        g.setPrice(rs.getString("price"));
                        g.setDescription(rs.getString("description"));
                        list.add(g);
                    }
                    return list;
                }
            }
        }
    }
}
