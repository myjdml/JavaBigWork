package org.example.controller;

import org.example.server.DB;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "productList", urlPatterns = "/productList")
public class ProductListServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding(String.valueOf(StandardCharsets.UTF_8));
        resp.setContentType("text/html");
        resp.setCharacterEncoding(String.valueOf(StandardCharsets.UTF_8));

        DB dbUtils = new DB();
        try {
            HttpSession session = req.getSession();
            session.setMaxInactiveInterval(3600);
            session.setAttribute("productList",dbUtils.getAllProducts());
        }catch ( SQLException |  ClassNotFoundException e) {
            e.printStackTrace();
        }


        req.getRequestDispatcher("/WEB-INF/view/productList.jsp").forward(req, resp);
    }
}
