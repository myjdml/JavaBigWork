const getProductListByCode = (code) => {
    $(".list").empty();
    productList.forEach((item, index) => {
        if (item.code === code) {
            $(".list").append(`
                <div class="list__item">
                  <div>`+ item.name +`</div>
                  <div>`+ item.sort +`</div>
                  <div>`+ item.code +`</div>
                  <div>`+ item.place +`</div>
                  <div>`+ item.price +`</div>
                  <div>`+ item.discription +`</div>
                </div>
            `)
        }

    })
}